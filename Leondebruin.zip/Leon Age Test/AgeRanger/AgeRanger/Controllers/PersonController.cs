﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AgeRanger.Controllers
{
    public class PersonController : ApiController
    {
        AgeRangerEntities objapi = new AgeRangerEntities();

        [HttpGet]
        public IEnumerable<Person_Select_Result> Get(string FirstName, string LastName, int? Age)
        {
            if (FirstName == "")
                FirstName = null;
            if (LastName == "")
                LastName = null;
            if (Age.ToString() == "")
                Age = null;
            return objapi.Person_Select(FirstName, LastName, Age).AsEnumerable();


        }

        [HttpGet]
        public int insertPerson(string FirstName, string LastName, int Age)
        {
            return objapi.Person_Insert_Update(null, FirstName, LastName, Age);           
        }

        [HttpGet]
        public int updatePerson(int PerID,string FirstName, string LastName, int Age)
        {
            return objapi.Person_Insert_Update(PerID, FirstName, LastName, Age);
        }


        [HttpGet]
        public string deletePerson(int PerId)
        {
            objapi.Person_Delete(PerId);
            objapi.SaveChanges();
            return "deleted";
        }
    }
}
